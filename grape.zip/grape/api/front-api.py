from fastapi import FastAPI, File, UploadFile,Request,status
import uvicorn
import numpy as np
from fastapi.responses import HTMLResponse
from PIL import Image
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from PIL import Image
import tensorflow as tf
from gtts import gTTS
from playsound import playsound


language='en'
app = FastAPI()
templates = Jinja2Templates(directory="C:\\Users\\Dayanand\\Corn\\templets")
app.mount("/static", StaticFiles(directory="C:\\Users\\Dayanand\\Corn\\static"), name="static")
MODEL = tf.keras.models.load_model("C:\\Users\\Dayanand\\Corn\\potatoes.h5")
CLASS_NAMES = ['Black Rot', 'ESCA', 'Healthy', 'Leaf Blight']
app.mount("/templets",StaticFiles(directory="C:\\Users\\Dayanand\\Corn\\templets"),name="tem")



def read_file_as_image(data) -> np.ndarray:
    image = np.array(Image.open(data))
    return image


@app.get('/a',response_class=HTMLResponse)
def home(request:Request):
    return templates.TemplateResponse("home.html", {"request": request})


@app.get('/contact',response_class=HTMLResponse)
def contact(request:Request):
    return templates.TemplateResponse("contact.html", {"request": request})



@app.get('/file-upload', response_class=HTMLResponse)
def get_basic_form(request: Request):
    return templates.TemplateResponse("detect.html", {"request": request})


@app.post('/file-upload', response_class=HTMLResponse)
async def post_basic_form(request: Request,file: UploadFile = File(...)):
    i= await file.read()
    with open(f"C:\\Users\\Dayanand\\Corn\\static\\input.jpg", "wb") as f:
        f.write(i)
    im=Image.open("C:\\Users\\Dayanand\\Corn\\static\\input.jpg")
    im.resize((255,255));
    im.save("nput.jpg")
    #m=Image.open("C:\\Users\\Dayanand\\Corn\\nput.jpg")
   # n=m.tobytes()
    image = read_file_as_image("C:\\Users\\Dayanand\\Corn\\nput.jpg")
    img_batch = np.expand_dims(image, 0)
    predictions = MODEL.predict(img_batch)
    predicted_class = CLASS_NAMES[np.argmax(predictions[0])]
    confidence = round(100 *(np.max(predictions[0])),2)
    if(predicted_class=="Black Rot"):
        x="This disease is caused by the Fungus Guignardia Bidwellii. This Fungus infect the leaves"
        b="""Controlling of this disease can be done by Sanitation and using Protectant Fungicides such as Mancozeb, and Ziram and are this are highly effective against block rot."""
        sound=gTTS(text="Black Rot")
        sound.save("s.mp3")
        playsound("C:\\Users\\Dayanand\\Corn\\s.mp3")
        return templates.TemplateResponse("detect.html", {"request": request, "id":predicted_class,"mar":float(confidence),"d":x,"c":b})

    elif(predicted_class=="ESCA"):
        sound=gTTS(text="ESCA")
        sound.save("s1.mp3")
        playsound("C:\\Users\\Dayanand\\Corn\\s1.mp3")
        y="""This disease is caused by the fungus Togninia minima.
        This disease may occur at any time during the growing seasons.
        This fungal disease leads to plant death."""
        c="Controlled by pruning method i.e., trimimg or cutting the leaf. And can also be controlled by organic control and Chemical control."
        return templates.TemplateResponse("detect.html", {"request": request, "id":predicted_class,"mar":float(confidence),"d":y,"c":c})

    elif(predicted_class=="Healthy"):
        sound=gTTS(text="Healthy")
        sound.save("s2.mp3")
        playsound("C:\\Users\\Dayanand\\Corn\\s2.mp3")
        z="This leaves are good content in Iron, Fiber, Magnesium, and vitamins"
        s="nothing"
        return templates.TemplateResponse("detect.html", {"request": request, "id":predicted_class,"mar":float(confidence),"d":z,"c":s})

    elif(predicted_class=="Leaf Blight"):
        sound=gTTS(text="Leaf Blight")
        sound.save("s3.mp3")
        playsound("C:\\Users\\Dayanand\\Corn\\s3.mp3")
        a="This disease is caused by the bacterium Xylophilus ampelinus. This bacterium leads to reduction in grapevine health and harvest loss"
        d="""There is no effective method to control this disease.
        Fungicides sprayed for other diseases in the season may help to reduce this disease."""
        return templates.TemplateResponse("detect.html", {"request": request, "id":predicted_class,"mar":float(confidence), "d":a,"c":d})



if __name__ == "__main__":
    uvicorn.run(app,  host='localhost', port=8004)